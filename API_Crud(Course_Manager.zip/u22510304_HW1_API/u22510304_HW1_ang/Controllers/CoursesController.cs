﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using u22510304_HW1_ang.Model;

namespace u22510304_HW1_ang.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CoursesController : ControllerBase
    {

        private readonly ICrourseRepo _crourseRepo;
        public CoursesController(ICrourseRepo crourseRepo)
        {
            _crourseRepo = crourseRepo;
         
        }

        [HttpGet]
        [Route("getAllCourses")]
        public async Task<IActionResult> GetAllCourses()
        {
            try
            {
                var courses = await _crourseRepo.GetAllCourses();
                var sortedCourses = courses.OrderByDescending(course => course.CourseID);
                return Ok(sortedCourses);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        [Route("GetCourse/{courseID}")]
        public async Task<IActionResult> GetCourse(int courseID)
        {
            try
            {
                return Ok(await _crourseRepo.GetCourse(courseID));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("AddCourse")]
        public async Task<IActionResult> AddCourse([FromBody] CourseList courseList)
        {
            try
            {
                var message = "Successfully Added Gaming Console";
                var added = await _crourseRepo.AddCourse(courseList );
                if (!added)
                {
                    message = "an error has occured.The Data was received but Failed to Add";
                }
                return Ok(new { message });
            }
            catch (Exception ex)
            {
           
                return BadRequest("An Error Occoured");
            }
        }

        [HttpPost]
        [Route("updateCourse")]
        public async Task<IActionResult> UpdateCourse([FromBody] CourseList courseList)
        {
            try
            {
                var message = "Successfully Updated course";
                var update = await _crourseRepo.UpdateCourse(courseList);
                if (!update)
                {
                    message = "an error has occured.The Data was received but Failed to Update";
                }
                return Ok(new { message });
            }
            catch (Exception ex)
            {
               
                return BadRequest("An Error Occoured");
            }
        }

        [HttpGet]
        [Route("deleteCourse/{courseId}")]
        public async Task<IActionResult> DeleteCourse(int courseID)
        {
            try
            {
                var message = "Successfully Delete Course";
                var added = await _crourseRepo.DeleteCourse(courseID);
                if (!added)
                {
                    message = "an error has occured.The Data not deleted";
                }
                return Ok(new { message });
            }
            catch (Exception ex)
            {
             
                return BadRequest("An Error Occoured , Please Try Again Later");
            }
        }



    }
}

