﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace u22510304_HW1_ang.Migrations
{
    /// <inheritdoc />
    public partial class SeededCourses : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Courses",
                columns: new[] { "CourseID", "CourseName", "Duration", "discription" },
                values: new object[,]
                {
                    { 1, "AIM101", "Semester", "Year 1, Semester 1. Academic Information Management" },
                    { 2, "FRK 113", "Semester 1", "Accounting Principles" },
                    { 3, "INF 200", "Year", "Introduction to API's" },
                    { 4, "INF 345", "Year", "  Advanced Programming" },
                    { 5, "INF 200", "Year", "Taxonomies" },
                    { 6, "INF 345", "semester", "Year 2, Semester 1. Academic\r\nInformation Management" },
                    { 7, "INF370", "Year", "Year 3.Project" },
                    { 8, "INF354", "Semester", "Year 3, Semester 1Programming" },
                    { 9, "INF324", "Semester", " Year 3, Semester 2" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Courses",
                keyColumn: "CourseID",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Courses",
                keyColumn: "CourseID",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Courses",
                keyColumn: "CourseID",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Courses",
                keyColumn: "CourseID",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Courses",
                keyColumn: "CourseID",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Courses",
                keyColumn: "CourseID",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Courses",
                keyColumn: "CourseID",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Courses",
                keyColumn: "CourseID",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Courses",
                keyColumn: "CourseID",
                keyValue: 9);
        }
    }
}
