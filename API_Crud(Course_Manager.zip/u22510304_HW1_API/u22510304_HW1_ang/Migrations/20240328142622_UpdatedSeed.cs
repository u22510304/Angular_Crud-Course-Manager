﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace u22510304_HW1_ang.Migrations
{
    /// <inheritdoc />
    public partial class UpdatedSeed : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "discription",
                table: "Courses",
                newName: "Discription");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Discription",
                table: "Courses",
                newName: "discription");
        }
    }
}
