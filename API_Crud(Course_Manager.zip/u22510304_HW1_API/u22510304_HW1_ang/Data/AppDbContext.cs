﻿
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using u22510304_HW1_ang.Model;

namespace u22510304_HW1_ang.Data
{
    public class AppDbContext : DbContext
    {
        //initailization
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        //Set Tables
        public DbSet<CourseList> Courses { get; set; }


        // run defult constructor method

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            //Seeded Data

            var MyCourses = new CourseList[]
            {
                new CourseList{CourseID=1, CourseName="AIM101", Duration = "Semester", Discription = "Year 1, Semester 1. Academic Information Management"},

                new CourseList{CourseID=2, CourseName="FRK 113", Duration = "Semester 1", Discription = "Accounting Principles"},

                new CourseList{CourseID=3, CourseName="INF 200", Duration = "Year", Discription = "Introduction to API's"},
                
                new CourseList{CourseID=4, CourseName = "INF 345", Duration = "Year", Discription = "  Advanced Programming" },

                new CourseList{CourseID=5, CourseName = "INF 200", Duration = "Year", Discription = "Taxonomies" },

                new CourseList{CourseID=6, CourseName = "INF 345", Duration = "semester", Discription = "Year 2, Semester 1. Academic\r\nInformation Management" },
              
                new CourseList{CourseID=7, CourseName = "INF370", Duration = "Year", Discription = "Year 3.Project" },

                new CourseList{CourseID=8, CourseName = "INF354", Duration = "Semester", Discription = "Year 3, Semester 1Programming" },

                new CourseList{CourseID=9, CourseName = "INF324", Duration = "Semester", Discription = " Year 3, Semester 2" },

            };

            builder.Entity<CourseList>().HasData(MyCourses);

        }
    }
}


