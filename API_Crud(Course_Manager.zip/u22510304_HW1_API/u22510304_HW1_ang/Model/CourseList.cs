﻿using System.ComponentModel.DataAnnotations;

namespace u22510304_HW1_ang.Model
{
    public class CourseList
    {
        [Key]
        public int CourseID { get; set; }
        public string CourseName { get; set; }
        public string Duration { get; set; }
        public string Discription { get; set; }




    }
}
