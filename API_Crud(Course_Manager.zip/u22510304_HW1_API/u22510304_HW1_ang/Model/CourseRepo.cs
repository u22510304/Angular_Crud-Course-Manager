﻿


using Microsoft.EntityFrameworkCore;
using u22510304_HW1_ang.Data;
namespace u22510304_HW1_ang.Model
{


    public class CourseRepo : ICrourseRepo
    {
        private readonly AppDbContext _appDbContext;


        public CourseRepo(AppDbContext appDbContext)
    {
            _appDbContext = appDbContext;
    }
        public async Task<bool> AddCourse(CourseList course)//c
        {
        _appDbContext.Courses.AddAsync(course); 
            await _appDbContext.SaveChangesAsync();
            return true;
        }


        public async Task<CourseList> GetCourse(int courseID)//r
    {
            return await _appDbContext.Courses.Where(x => x.CourseID == courseID).FirstOrDefaultAsync();

        }


        public async Task<List<CourseList>> GetAllCourses()//r -1
{
           return await _appDbContext.Courses.ToListAsync();
        }


        public async Task<bool> UpdateCourse(CourseList course)//u
{
            try
            {
                _appDbContext.Courses.Update(course);
                await _appDbContext.SaveChangesAsync();
                
            }
            catch (Exception ex) {
                return false;
            }
            return true;
        }


        public async Task<bool> DeleteCourse(int courseID)// d
{
            var Course = await GetCourse(courseID);
            try
            {
                _appDbContext.Courses.Remove(Course);
                await _appDbContext.SaveChangesAsync();

            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }



    }
}
