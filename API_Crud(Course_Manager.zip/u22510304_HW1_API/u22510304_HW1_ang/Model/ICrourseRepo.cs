﻿namespace u22510304_HW1_ang.Model
{
    public interface ICrourseRepo
    {
        //Define methods
        Task<bool> AddCourse(CourseList course);//c
        Task<List<CourseList>> GetAllCourses();//r -1
        Task<CourseList> GetCourse(int courseID);//r
        Task<bool> UpdateCourse(CourseList course);//u
        Task<bool> DeleteCourse(int courseID);// d

    }
}
