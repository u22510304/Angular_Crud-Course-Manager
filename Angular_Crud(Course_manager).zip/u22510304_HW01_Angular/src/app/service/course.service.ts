import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Course } from '../Classes/Course';

@Injectable({
  providedIn: 'root'
})
export class CourseService {

  constructor(private http:HttpClient) { }
  endPoint : string = "https://localhost:7023/api/Courses/";

  GetAllCourses()
  {
    return this.http.get<Course[]>(this.endPoint + 'getAllCourses')
  }

  GetCourse(courseID: number) {
    return this.http.get<Course>(this.endPoint + `GetCourse/${courseID}`);
  }
  

  AddCourses(course: Course )
  {
    return this.http.post<string>(this.endPoint + 'AddCourse', course)
  }

  UpdateCourses(course: Course) {
    return this.http.post<string>(this.endPoint + 'updateCourse', course);
  }

DeleteCourses(courseID: number) {
  return this.http.get<string>(this.endPoint + `deleteCourse/${courseID}`);
}
}
