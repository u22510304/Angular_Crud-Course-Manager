import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Course } from 'src/app/Classes/Course';
import { CourseService } from 'src/app/service/course.service';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-course-edit',
  templateUrl: './course-edit.component.html',
  styleUrls: ['./course-edit.component.css']
})
export class CourseEditComponent {
  [x: string]: any;

    editForm  : FormGroup = new FormGroup({
    courseName : new FormControl("",[ Validators.required]),
    duration: new FormControl("",[ Validators.required]),
    discription: new FormControl("",[ Validators.required]),
  })

  peramiter!: Subscription ;
  courseID! : number;
  course !: Course;
  constructor(private courseService: CourseService, private route:Router, private activatedRoute : ActivatedRoute){
  
  }
  ngOnInit(){
    this.peramiter = this.activatedRoute.params.subscribe(parms => {
      this.courseID = parms["courseID"];
      console.log("Course ID:", this.courseID); // Add this line for debugging
      this.fetchCourse();
    });
  }
  
  

  fetchCourse()
  {
    this.courseService.GetCourse(this.courseID).subscribe({
      next: (res: Course) => {
        console.log(res);
        this.clearForm();
        this.course = res;
        this.assignValues();
      },
      error: err => {
        console.log(err);
      }  
    });
  }
  
    assignValues() {
      this.editForm.controls["courseName"].setValue(this.course.courseName);
      this.editForm.controls["duration"].setValue(this.course.duration);
      this.editForm.controls["discription"].setValue(this.course.discription);
    }
  
    clearForm() {
      this.editForm.reset();
    }
  
  

  onedit(){
    console.log('Form is valid:', this.editForm.valid);
    if(this.editForm.invalid){
      Object.values(this.editForm.controls).forEach(control =>{
        if(control.invalid){
          control.markAsDirty();
          control.updateValueAndValidity({onlySelf: true});
          console.log('error')
        }
      })
    } else {
      // Make sure this.course is initialized before accessing its properties
      if (!this.course) {
        return;
      }
  
      let courseList = new Course();
      courseList.courseID = this.course.courseID;
      courseList.courseName = this.editForm.controls["courseName"].value;
      courseList.duration = this.editForm.controls["duration"].value;
      courseList.discription = this.editForm.controls["discription"].value;
      this.courseService.UpdateCourses(courseList).subscribe({
        next: res => {
          console.log('Update response:', res);
          console.log(res);
          
          this.clearForm();
          this.route.navigateByUrl("/home");
        },
        error: err => {
          console.log('Update error:', err);
        }  
      });
    }
  }
  

OnCancel(){
  this.route.navigateByUrl("/home");

}

}
