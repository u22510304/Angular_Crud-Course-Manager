import { Component } from '@angular/core';
import { Course } from 'src/app/Classes/Course';
import { CourseService } from 'src/app/service/course.service';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent {

  constructor (private courseservice: CourseService) { }
  courses: Course[] = [];
  ngOnInit() {
    this.courseservice.GetAllCourses().subscribe(res => {
      this.courses = res;
      console.log(this.courses);
    });

  }
  
  onEditClick(courseID: number) {
    console.log('Edit clicked for course ID:', courseID);
  }
  getAllCourses()
  {
    this.courseservice.GetAllCourses().subscribe(res => {
      this.courses = res;
      console.log(res);
    });
  }

  onDelete(courseID: number){
    this.courseservice.DeleteCourses(courseID).subscribe(res => {
      location.reload();
  });
}
}

