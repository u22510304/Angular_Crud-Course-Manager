import { Component } from '@angular/core';
import { FormControl,FormGroup, Validator, Validators } from '@angular/forms';
import { Course } from 'src/app/Classes/Course';
import { CourseService } from 'src/app/service/course.service';
import { Route,Router } from '@angular/router';


@Component({
  selector: 'app-course-add',
  templateUrl: './course-add.component.html',
  styleUrls: ['./course-add.component.css']
})
export class CourseAddComponent {

//construct form

addForm :FormGroup = new FormGroup({
  courseName : new FormControl("",[ Validators.required]),
  duration: new FormControl("",[ Validators.required]),
  discription: new FormControl("",[ Validators.required]),
})
constructor(private courseService: CourseService, private route:Router){

}
ngOnInit(){

  this.clearForm();

}

clearForm(){
  this.addForm.reset()
}

onAdd(){
//collect form data
if(this.addForm.invalid){
  Object.values(this.addForm.controls).forEach(control =>{
    if(control.invalid){
      control.markAsDirty();
      control.updateValueAndValidity({onlySelf: true});
      console.log("not working");
      
    }
  })


}
else
{
  let course = new Course();
  course.courseName = this.addForm.controls["courseName"].value;
  course.duration = this.addForm.controls["duration"].value;
  course.discription = this.addForm.controls["discription"].value;
  this.courseService.AddCourses(course).subscribe({
    next: res => {
      this.clearForm();
      this.route.navigateByUrl("/home");
      
    },
    error: err => {
      console.log(err);
    }
  });


}
}
OnCancel(){
  this.route.navigateByUrl("/home");


}


}
