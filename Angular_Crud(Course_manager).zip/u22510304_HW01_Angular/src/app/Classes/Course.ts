export class Course {
    courseID!: number;
    courseName!: string;
    duration!: string;
    discription!: string;
}