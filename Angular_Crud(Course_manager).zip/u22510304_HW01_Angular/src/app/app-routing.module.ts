import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CourseAddComponent } from './course/course-add/course-add.component';  
import { CourseEditComponent } from './course/course-edit/course-edit.component';
import { CourseListComponent } from './course/course-list/course-list.component';


const routes: Routes = [
  {path: '', pathMatch:'full', redirectTo: 'home' },
  {path: 'home', component: CourseListComponent},
  { path: 'update/:courseID', component: CourseEditComponent },
  {path: 'add', component: CourseAddComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
